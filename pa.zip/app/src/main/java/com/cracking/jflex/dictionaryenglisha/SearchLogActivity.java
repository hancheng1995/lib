package com.cracking.jflex.dictionaryenglisha;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class SearchLogActivity extends AppCompatActivity implements RecyclerItemClickListener {

    private ArrayList<String> searchList;

    private RecyclerView searchLogListView;
    private SearchLogAdapter searchLogAdapter;

    private DBUtil dbUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_log);

        dbUtil = new DBUtil(this);

        searchLogListView = (RecyclerView) findViewById(R.id.searchListView);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        searchLogListView.setHasFixedSize(true);
        searchLogListView.setLayoutManager(layoutManager);
        searchLogListView.setItemAnimator(new DefaultItemAnimator());

        loadSearchLog();
    }

    private void loadSearchLog() {
        searchList = dbUtil.getSearchLogs();
        if (searchList.size() > 0) {
            searchLogAdapter = new SearchLogAdapter(searchList, this);
            searchLogListView.setAdapter(searchLogAdapter);
            searchLogAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, " 검색 기록이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public void onItemClick(DictObj dictObj) {

    }

    @Override
    public void onLogItemClick(int index) {

    }
}
