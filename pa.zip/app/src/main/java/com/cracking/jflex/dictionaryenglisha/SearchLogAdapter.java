package com.cracking.jflex.dictionaryenglisha;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class SearchLogAdapter extends RecyclerView.Adapter<SearchLogAdapter.MyViewHolder> {

    private ArrayList<String> searchLogDataPack;
    private RecyclerItemClickListener recyclerItemClickListener;

    public SearchLogAdapter(ArrayList<String> searchLogDataPack, RecyclerItemClickListener listener) {
        this.searchLogDataPack = searchLogDataPack;
        this.recyclerItemClickListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_search, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return searchLogDataPack.size();
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {
        myViewHolder.txtSearchWord.setText(searchLogDataPack.get(i));
        myViewHolder.txtSearchWord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerItemClickListener.onLogItemClick(i);
            }
        });
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtSearchWord;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtSearchWord = itemView.findViewById(R.id.search_word);
        }

    }
}
