package com.cracking.jflex.dictionaryenglisha;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RecyclerItemClickListener {

    public static final int REQ_BOOKMARK = 90;

    private static String PATH_CSV_A = String.valueOf(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)) + "/A.csv";

    private DBUtil dbUtil;
    private PreferenceUtil preferenceUtil;

    private ArrayList<DictObj> dictList;

    private RecyclerView dictListView;
    private EditText editSearchDict;
    private Button mBtnLike;
    private Button mBtnHist;
    private Button mBtnSearch;

    private DictAdapter dictAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("[설정]>[권한]에서 권한을 허용하시기 바랍니다.")
                .setPermissions(Manifest.permission.READ_EXTERNAL_STORAGE)
                .check();

        dbUtil = new DBUtil(this);
        preferenceUtil = new PreferenceUtil(this);

        dictListView = (RecyclerView) findViewById(R.id.listVewDict);
        editSearchDict = (EditText) findViewById(R.id.editSearchDict);
        mBtnLike = (Button) findViewById(R.id.btnBookmark);
        mBtnHist = (Button) findViewById(R.id.btnHistory);
        mBtnSearch = (Button) findViewById(R.id.btnSearch);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        dictListView.setHasFixedSize(true);
        dictListView.setLayoutManager(layoutManager);
        dictListView.setItemAnimator(new DefaultItemAnimator());

        mBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchDict();
            }
        });

        mBtnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, BookmarkActivity.class);
                startActivityForResult(intent, REQ_BOOKMARK);
            }
        });

        mBtnHist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SearchLogActivity.class);
                startActivity(intent);
            }
        });
    }

    PermissionListener permissionlistener = new PermissionListener() {
        @Override
        public void onPermissionGranted() {
            if (!preferenceUtil.getFirst()) {
                if (isExistsDataSheet()) {
                    new AppFirstRunTask().execute();
                } else {
                    Toast.makeText(MainActivity.this, "저장소에 엑셀 데이터파일이 없습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            } else if (preferenceUtil.getFirst()) {
                new AppLoadDictTask().execute();
            }
        }

        @Override
        public void onPermissionDenied(List<String> deniedPermissions) {
            Toast.makeText(MainActivity.this, "[설정]>[권한]에서 파일 읽기 권한을 허용하시기 바랍니다.", Toast.LENGTH_SHORT).show();
            finish();
        }

    };

    private boolean isExistsDataSheet() {
        File sheet = new File(PATH_CSV_A);
        if (sheet.exists()) {
            return true;
        } else {
            return false;
        }
    }

    private boolean saveDatasPref() {
        String line;
        ArrayList<String> excelLines = new ArrayList<>();
        File sheet = new File(PATH_CSV_A);

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(sheet)));

            while ((line = br.readLine()) != null) {
                if (!line.isEmpty()) {
                    line = line.replace("\"", "");
                    excelLines.add(line);
                }
            }

            if (excelLines != null) {
                dbUtil.add(excelLines);
                preferenceUtil.setFirst();
            }

            return true;
        } catch (Exception e) {
            Log.e("saveDataPref", e.getMessage());
            return false;
        }
    }

    private boolean loadDictData() {
        try {
            dictList = dbUtil.getAll();
            return true;
        } catch (Exception e) {
            Log.e("loadDictData", e.getMessage());
            return false;
        }
    }

    public class AppFirstRunTask extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("앱 최초 작업 중..");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {
            if (saveDatasPref()) {
                if (loadDictData()) {
                    return "success";
                } else {
                    return "failed";
                }
            } else {
                return "failed";
            }
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            if (aVoid.equals("success")) {
                loadDictList(dictList);
            } else {
                Toast.makeText(MainActivity.this, "에러가 발생하였습니다.", Toast.LENGTH_SHORT).show();
                finish();
            }
            progressDialog.dismiss();
        }
    }

    public class AppLoadDictTask extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("사전 데이터 로딩중..");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {
            if (loadDictData()) {
                return "success";
            } else {
                return "failed";
            }
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            if (aVoid.equals("success")) {
                loadDictList(dictList);
            } else {
                Toast.makeText(MainActivity.this, "에러가 발생하였습니다.", Toast.LENGTH_SHORT).show();
                finish();
            }
            progressDialog.dismiss();
        }
    }

    public class UpdateDictTask extends AsyncTask<String, Void, String> {

        ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.setCancelable(false);
            progressDialog.setMessage("데이터 로딩중..");
            progressDialog.show();
        }

        @Override
        protected String doInBackground(String... voids) {
            if (loadDictData()) {
                return "success";
            } else {
                return "failed";
            }
        }

        @Override
        protected void onPostExecute(String aVoid) {
            super.onPostExecute(aVoid);
            if (aVoid.equals("success")) {
                searchDict();
            } else {
                Toast.makeText(MainActivity.this, "에러가 발생하였습니다.", Toast.LENGTH_SHORT).show();
                finish();
            }
            progressDialog.dismiss();
        }
    }

    private void loadDictList(ArrayList<DictObj> dictList) {
        dictAdapter = new DictAdapter(dictList, this);
        dictListView.setAdapter(dictAdapter);
        dictAdapter.notifyDataSetChanged();
    }

    private void searchDict() {
        if (!editSearchDict.getText().toString().isEmpty()) {
            ArrayList<DictObj> searchedList = new ArrayList<>();
            int cnt = 0;
            for (int i = 0; i < dictList.size(); i++) {
                if (dictList.get(i).word.toLowerCase().startsWith(editSearchDict.getText().toString())) {
                    if (cnt > 4) {
                        break;
                    }
                    searchedList.add(dictList.get(i));
                    cnt++;
                }
            }
            dbUtil.insertSearchLog(editSearchDict.getText().toString());
            loadDictList(searchedList);
        } else {
            loadDictList(dictList);
        }
    }

    @Override
    public void onItemClick(DictObj dictObj) {
        if (dictObj != null) {
            if (dictObj.isChecked == 0) {
                dbUtil.updateChk(new DictObj(dictObj.index, dictObj.word, dictObj.desc, 1));
            } else {
                dbUtil.updateChk(new DictObj(dictObj.index, dictObj.word, dictObj.desc, 0));
            }
        }
        new UpdateDictTask().execute();
    }

    @Override
    public void onLogItemClick(int index) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            Log.e("res", String.valueOf(requestCode));
            switch (requestCode) {
                case REQ_BOOKMARK:
                    new UpdateDictTask().execute();
                    break;
            }
        }
    }
}
