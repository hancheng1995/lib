package com.cracking.jflex.dictionaryenglisha;

public class DictObj {
    public int index;
    public String word;
    public String desc;
    public int isChecked;

    public DictObj(int index,String word, String desc, int isChecked) {
        this.index = index;
        this.word = word;
        this.desc = desc;
        this.isChecked = isChecked;
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getIsChecked() {
        return isChecked;
    }

    public void setIsChecked(int isChecked) {
        this.isChecked = isChecked;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
