package com.cracking.jflex.dictionaryenglisha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class BookmarkActivity extends AppCompatActivity implements RecyclerItemClickListener {

    private ArrayList<DictObj> dictList;

    private RecyclerView bookmarkListView;
    private BookmarkAdapter dictAdapter;

    private DBUtil dbUtil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark);

        dbUtil = new DBUtil(this);

        bookmarkListView = (RecyclerView) findViewById(R.id.bookmarkListView);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        bookmarkListView.setHasFixedSize(true);
        bookmarkListView.setLayoutManager(layoutManager);
        bookmarkListView.setItemAnimator(new DefaultItemAnimator());

        loadBookmarkData();
    }

    private void loadBookmarkData() {
        dictList = dbUtil.getChkData();
        Log.e("dictlength", String.valueOf(dictList.size()));
        if (dictList.size() > 0) {
            dictAdapter = new BookmarkAdapter(dictList, this);
            bookmarkListView.setAdapter(dictAdapter);
            dictAdapter.notifyDataSetChanged();
        } else {
            Toast.makeText(this, "북마크 데이터가 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        }
    }

    @Override
    public void onItemClick(DictObj dictObj) {
        if (dictObj != null) {
            //update uncheck bookmark
            dbUtil.updateUnChk(dictObj);
            Toast.makeText(this, "해당 단어를 북마크에서 해제하였습니다.", Toast.LENGTH_SHORT).show();
        }
        loadBookmarkData();
    }

    @Override
    public void onLogItemClick(int index) {

    }

    @Override
    public void onBackPressed() {
        setResult(RESULT_OK);
        finish();
        super.onBackPressed();
    }
}
