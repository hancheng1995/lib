package com.cracking.jflex.dictionaryenglisha;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBUtil extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "DICTDB";

    private static final String TABLE_DICT = "DICT";
    private static final String TABLE_SEARCH = "SE";

    private static final String KEY_ID_DICT = "id";
    private static final String KEY_WORD_DICT = "word";
    private static final String KEY_DESC_DICT = "word_text";
    private static final String KEY_WISH_DICT = "is_wish";

    private static final String KEY_ID_SE = "id";
    private static final String KEY_WORD_SE = "word";

    public DBUtil(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE_DICT = "CREATE TABLE " + TABLE_DICT + " (" + KEY_ID_DICT + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_DESC_DICT + " TEXT NOT NULL," + KEY_WISH_DICT + " INTEGER DEFAULT 0)";
        String CREATE_TABLE_SEARCH = "CREATE TABLE " + TABLE_SEARCH + " (" + KEY_ID_SE + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_WORD_SE + " TEXT NOT NULL)";
        sqLiteDatabase.execSQL(CREATE_TABLE_DICT);
        sqLiteDatabase.execSQL(CREATE_TABLE_SEARCH);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String DROP_TABLE_DRINK =
                "DROP TABLE IF EXISTS " + TABLE_DICT;
        sqLiteDatabase.execSQL(DROP_TABLE_DRINK);

        onCreate(sqLiteDatabase);
    }

    public void add(ArrayList<String> dictDatas) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            for (String data : dictDatas) {
                ContentValues values = new ContentValues();
                values.put(KEY_DESC_DICT, data);

                db.insert(TABLE_DICT, null, values);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void insertSearchLog(String searchWord) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(KEY_WORD_SE, searchWord);

            db.insert(TABLE_SEARCH, null, values);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void updateChk(DictObj obj) {
        SQLiteDatabase db = this.getWritableDatabase();

        int target_index = obj.index;
        String sql = "update " + TABLE_DICT + " SET " + KEY_WISH_DICT + "=" + obj.isChecked + " where " + KEY_ID_DICT + "=" + target_index;

        db.execSQL(sql);
    }

    public void updateUnChk(DictObj obj) {
        SQLiteDatabase db = this.getWritableDatabase();

        int target_index = obj.index;
        String sql = "update " + TABLE_DICT + " SET " + KEY_WISH_DICT + "= 0" + " where " + KEY_ID_DICT + "=" + target_index;

        db.execSQL(sql);
    }

    public ArrayList<DictObj> getAll() {
        ArrayList<DictObj> dictList = new ArrayList<DictObj>();

        String SELECT_ALL = "SELECT * FROM " + TABLE_DICT;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(SELECT_ALL, null);

        if (cursor.moveToFirst()) {
            do {
                int idx = Integer.parseInt(cursor.getString(0));
                String word = cursor.getString(1).split("[(]")[0].trim();
                String desc = cursor.getString(1);
                int isChecked = Integer.parseInt(cursor.getString(2));

                DictObj dictObj = new DictObj(idx, word, desc, isChecked);
                dictList.add(dictObj);
            } while (cursor.moveToNext());
        }

        return dictList;
    }

    public ArrayList<DictObj> getChkData() {
        ArrayList<DictObj> dictList = new ArrayList<DictObj>();

        String SELECT_ALL = "SELECT * FROM " + TABLE_DICT + " WHERE " + KEY_WISH_DICT + "=1";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(SELECT_ALL, null);

        if (cursor.moveToFirst()) {
            do {
                int idx = Integer.parseInt(cursor.getString(0));
                String word = cursor.getString(1).split("[(]")[0].trim();
                String desc = cursor.getString(1);
                int isChecked = Integer.parseInt(cursor.getString(2));

                DictObj dictObj = new DictObj(idx, word, desc, isChecked);
                dictList.add(dictObj);
            } while (cursor.moveToNext());
        }

        return dictList;
    }

    public ArrayList<String> getSearchLogs() {
        ArrayList<String> logList = new ArrayList<String>();

        String SELECT_ALL = "SELECT * FROM " + TABLE_SEARCH;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(SELECT_ALL, null);

        if (cursor.moveToFirst()) {
            do {
                logList.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }

        return logList;
    }
}
