package com.cracking.jflex.dictionaryenglisha;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class BookmarkAdapter extends RecyclerView.Adapter<BookmarkAdapter.MyViewHolder> {

    private ArrayList<DictObj> mDictDataPack;
    private RecyclerItemClickListener recyclerItemClickListener;

    public BookmarkAdapter(ArrayList<DictObj> dictDataPack, RecyclerItemClickListener listener) {
        this.mDictDataPack = dictDataPack;
        this.recyclerItemClickListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_book, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public int getItemCount() {
        return mDictDataPack.size();
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {
        myViewHolder.txtWord.setText(mDictDataPack.get(i).desc);

        myViewHolder.imgDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                recyclerItemClickListener.onItemClick(mDictDataPack.get(i));
            }
        });
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtWord;
        public ImageView imgDel;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtWord = itemView.findViewById(R.id.word);
            imgDel = itemView.findViewById(R.id.delete);
        }

    }
}
