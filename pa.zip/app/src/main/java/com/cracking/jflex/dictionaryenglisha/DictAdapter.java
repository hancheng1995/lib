package com.cracking.jflex.dictionaryenglisha;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DictAdapter extends RecyclerView.Adapter<DictAdapter.MyViewHolder> {

    private ArrayList<DictObj> mDictDataPack;
    private RecyclerItemClickListener recyclerItemClickListener;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtDesc;
        public ImageView imgChk;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtDesc = itemView.findViewById(R.id.desc);
            imgChk = itemView.findViewById(R.id.chk);
        }
    }

    public DictAdapter(ArrayList<DictObj> dictDataPack, RecyclerItemClickListener listener) {
        this.mDictDataPack = dictDataPack;
        this.recyclerItemClickListener = listener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_dict, viewGroup, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, final int i) {
        myViewHolder.txtDesc.setText(mDictDataPack.get(i).desc);

        if (mDictDataPack.get(i).isChecked == 0) {
            myViewHolder.imgChk.setImageResource(R.drawable.ic_star_unchk);
        } else {
            myViewHolder.imgChk.setImageResource(R.drawable.ic_star_chk);
        }

        myViewHolder.imgChk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mDictDataPack.get(i).isChecked == 0) {
                    myViewHolder.imgChk.setImageResource(R.drawable.ic_star_chk);
                    Toast.makeText(view.getContext(), "북마크에 추가하였습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    myViewHolder.imgChk.setImageResource(R.drawable.ic_star_unchk);
                    Toast.makeText(view.getContext(), "북마크를 해제하였습니다.", Toast.LENGTH_SHORT).show();
                }
                recyclerItemClickListener.onItemClick(mDictDataPack.get(i));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mDictDataPack.size();
    }


}
