package com.cracking.jflex.dictionaryenglisha;

import android.view.View;

public interface RecyclerItemClickListener{
    void onItemClick(DictObj dictObj);
    void onLogItemClick(int index);
}
