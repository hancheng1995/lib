package com.cracking.jflex.dictionaryenglisha;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceUtil {

    Context mContext;
    SharedPreferences sharedPreferences;

    public PreferenceUtil(Context context) {
        this.mContext = context;
        sharedPreferences = mContext.getSharedPreferences("isFirst", Context.MODE_PRIVATE);
    }

    public void setFirst() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isFirst", true);
        editor.commit();
    }

    public boolean getFirst() {
        return sharedPreferences.getBoolean("isFirst", false);
    }
}
